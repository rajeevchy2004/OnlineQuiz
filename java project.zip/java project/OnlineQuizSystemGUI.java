import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class OnlineQuizSystemGUI extends JFrame implements ActionListener {
      // Components for the GUI
      JLabel questionLabel, timerLabel, headerLabel;
      JRadioButton[] options = new JRadioButton[4];
      ButtonGroup optionsGroup;
      JButton nextButton;
      JPanel mainPanel, headerPanel, questionPanel, optionsPanel, footerPanel;
      int score = 0, currentQuestion = 0, timeLeft = 20;
      Timer timer;

      // Array to hold questions, options, and answers
      String[][] questions = {
                  { "Which method in Optional is used to check if a value is present?", "isEmpty()", "isPresent()", "get()", "orElse()", "2" },
                  { "What does the Optional.ofNullable() method do?", "Returns an empty Optional", "Returns a non-empty Optional",
                   "Throws a NullPointerException if the value is null", " Returns an Optional that contains the value if it's non-null, otherwise an empty Optional", "4" },
                  { "Which method will retrieve the value from an Optional, or provide a default if the value is absent?", " get()", "orElse()", "isPresent()",
                              "empty()", "2" },
                  { "Which method can be used to execute a piece of code if a value is present in an Optional?", "filter()", "map()", "ifPresent()", "orElse()", "3" },
                  { "Which method can be used to transform the value inside an Optional if it is present, without throwing an exception if it is empty?",
                   "filter()", "map()", "orElseThrow()", "isPresent()", "2" }
      };

      // Constructor to initialize the quiz
      public OnlineQuizSystemGUI() {
            setTitle("Online Quiz System");
            setSize(800, 600);
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            setLayout(new BorderLayout());

            // Main panel that holds all content
            mainPanel = new JPanel();
            mainPanel.setLayout(new BorderLayout());
            mainPanel.setBackground(Color.decode("#f5f5f5"));
            add(mainPanel);

            // Header panel (website-like header)
            headerPanel = new JPanel();
            headerPanel.setLayout(new FlowLayout());
            headerPanel.setBackground(Color.decode("#2c3e50"));
            headerLabel = new JLabel("Online Quiz System");
            headerLabel.setFont(new Font("SansSerif", Font.BOLD, 30));
            headerLabel.setForeground(Color.white);
            headerPanel.add(headerLabel);
            mainPanel.add(headerPanel, BorderLayout.NORTH);

            // Panel to hold question and options
            questionPanel = new JPanel();
            questionPanel.setLayout(new BorderLayout());
            questionPanel.setBackground(Color.decode("#ecf0f1"));
            questionPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
            mainPanel.add(questionPanel, BorderLayout.CENTER);

            // Question Label (centered in question panel)
            questionLabel = new JLabel();
            questionLabel.setFont(new Font("Arial", Font.BOLD, 22));
            questionLabel.setForeground(Color.decode("#34495e"));
            questionPanel.add(questionLabel, BorderLayout.NORTH);

            // Options Panel (with radio buttons)
            optionsPanel = new JPanel();
            optionsPanel.setLayout(new BoxLayout(optionsPanel, BoxLayout.Y_AXIS));
            optionsPanel.setBackground(Color.decode("#ecf0f1"));
            optionsGroup = new ButtonGroup();

            for (int i = 0; i < 4; i++) {
                  options[i] = new JRadioButton();
                  options[i].setFont(new Font("Arial", Font.PLAIN, 18));
                  options[i].setBackground(Color.decode("#ecf0f1"));
                  options[i].setForeground(Color.decode("#2c3e50"));
                  optionsGroup.add(options[i]);
                  optionsPanel.add(options[i]);
                  optionsPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacing between options
            }

            questionPanel.add(optionsPanel, BorderLayout.CENTER);

            // Footer panel for the timer and button
            footerPanel = new JPanel();
            footerPanel.setLayout(new BorderLayout());
            footerPanel.setBackground(Color.decode("#34495e"));
            footerPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
            mainPanel.add(footerPanel, BorderLayout.SOUTH);

            // Timer label
            timerLabel = new JLabel("Time left: 20 seconds");
            timerLabel.setFont(new Font("Arial", Font.BOLD, 18));
            timerLabel.setForeground(Color.white);
            footerPanel.add(timerLabel, BorderLayout.WEST);

            // Next Button (styled like a modern button)
            nextButton = new JButton("Next");
            nextButton.setFont(new Font("Arial", Font.BOLD, 18));
            nextButton.setBackground(Color.decode("#27ae60"));
            nextButton.setForeground(Color.white);
            nextButton.setFocusPainted(false);
            nextButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
            nextButton.addActionListener(this);
            footerPanel.add(nextButton, BorderLayout.EAST);

            // Display the first question
            displayQuestion();

            // Initialize the timer
            timer = new Timer(1000, new ActionListener() {
                  public void actionPerformed(ActionEvent e) {
                        timeLeft--;
                        timerLabel.setText("Time left: " + timeLeft + " seconds");

                        // If time runs out, move to the next question
                        if (timeLeft == 0) {
                              checkAnswer();
                              currentQuestion++;
                              displayQuestion();
                        }
                  }
            });
            timer.start();
      }

      // Method to display the current question and options
      public void displayQuestion() {
            if (currentQuestion >= questions.length) {
                  endQuiz();
                  return;
            }

            // Reset the timer
            timeLeft = 20;
            timerLabel.setText("Time left: 20 seconds");

            // Display the question and options
            questionLabel.setText("<html><body style='padding: 10px'>" + (currentQuestion + 1) + ". "
                        + questions[currentQuestion][0] + "</body></html>");
            for (int i = 0; i < 4; i++) {
                  options[i].setText(questions[currentQuestion][i + 1]);
            }

            // Clear selected option
            optionsGroup.clearSelection();
      }

      // Method to check if the selected answer is correct
      public void checkAnswer() {
            int correctAnswer = Integer.parseInt(questions[currentQuestion][5]);
            for (int i = 0; i < 4; i++) {
                  if (options[i].isSelected() && (i + 1) == correctAnswer) {
                        score++;
                  }
            }
      }

      // Method to handle button actions
      public void actionPerformed(ActionEvent e) {
            // If the next button is clicked, check the answer and move to the next question
            if (e.getSource() == nextButton) {
                  checkAnswer();
                  currentQuestion++;
                  displayQuestion();
            }
      }

      // Method to end the quiz and display the score
      public void endQuiz() {
            timer.stop(); // Stop the timer when quiz ends
            JOptionPane.showMessageDialog(this, "Quiz Completed!\nYour score: " + score + "/" + questions.length);
            System.exit(0); // Exit the application
      }

      // Main method to run the quiz
      public static void main(String[] args) {
            new OnlineQuizSystemGUI().setVisible(true);
      }
}